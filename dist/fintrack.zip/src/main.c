#include <stdio.h>
#include "../include/linkedlist.h"
#include <stdlib.h>
#include "../include/ui.h"
#include "../include/program.h"

int main() {
  // start the program
  start();
  return 0;
}
