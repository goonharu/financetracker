#ifndef UI_H
#define UI_H

#include <stdbool.h>

bool printWelcome();


#endif
